/*Escreva um programa que vai gerar (sem input do usu�rio) uma matriz 4x4 em que:
a. Todos os elementos da diagonal principal s�o 0
b. Todos os elementos acima da diagonal principal s�o 1
c. Todos os elementos abaixo da diagonal principal s�o -1*/
#include<stdio.h>

const int a=4;

int main()
{
	int i,j;
	
	int m[a][a];
	
	for(i=0;i<a;i++)//linha
	{
		for(j=0;j<a;j++)//Coluna
		{
			printf("Digite um numero: ");
			scanf("%d",&m[i][j]);
		}
		printf("\n");
	}
	for(i=0;i<a;i++)
	{
		for(j=0;j<a;j++)
		{
			if(i==j)
			{
				m[i][j]=0;
				// estou na diagonal principal
			}
			if(j>i)
			{
				// estou em um valor acima da diagonal principal
				m[i][j]=1;
			}
			if(j<i)	
			{
				// estou em um valor baixo da diagonal principal
				m[i][j]=-1;
			}
		}
	}
	printf("\nMatriz\n");
	for(i=0;i<a;i++)
	{
		for(j=0;j<a;j++)
		{
			printf("[%d]  ",m[i][j]);
		}
		printf("\n");
	}
	
	return 0;
}
